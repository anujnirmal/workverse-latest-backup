(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.2);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.30000000000001);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.30000000000001);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.2);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.2);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,196,229,0.008)","#00C4E5","#10DCFF","#00C4E5","rgba(0,196,229,0)"],[0,0.357,0.478,0.639,1],-171.4,0,171.5,0).s().p("A6yGMIAAsXMA1kAAAIAAMXg");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-171.4,-39.6,342.9,79.30000000000001);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgElgohIBJgHMAICBRKIhJAHg");
	mask.setTransform(0,0.025);

	// Layer_2
	this.instance = new lib.Symbol11("synched",0);
	this.instance.setTransform(59.55,466.45,1,1,-96.7818,0,0,-0.1,0);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0,scaleX:0.9996,scaleY:0.9996,rotation:-96.7599,x:-47.4,y:-434.95},134).wait(6).to({regX:-0.1,scaleX:1,scaleY:1,rotation:-96.7818,x:59.55,y:466.45},0).to({regX:0,scaleX:0.9996,scaleY:0.9996,rotation:-96.7599,x:-47.4,y:-434.95},134).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.4,-260.1,58.8,520.3);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgRVAk7MAhnhKTIBEAeMghnBKTg");

	// Layer_2
	this.instance = new lib.Symbol12("synched",0);
	this.instance.setTransform(191.95,-390.25,1,1,114.5468);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-183.55,y:398.8},124).wait(26));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110.9,-239.3,221.9,478.70000000000005);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A8pdCMA4eg62IA1AzMg4eA62g");
	var mask_graphics_274 = new cjs.Graphics().p("A8pdCMA4eg62IA1AzMg4eA62g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:0.025,y:0}).wait(274).to({graphics:mask_graphics_274,x:0.025,y:0}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_2
	this.instance = new lib.Symbol10("synched",0);
	this.instance.setTransform(-60.4,79.2,0.9959,0.9959,129.5995);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,rotation:129.5579,x:-289.7,y:332.7},55).wait(1).to({x:279.25,y:-304.7},0).to({scaleX:0.9975,scaleY:0.9975,rotation:129.5945,x:-56.25,y:74.6},81).to({scaleX:1,scaleY:1,rotation:129.5579,x:-289.7,y:332.7},72).wait(1).to({x:279.25,y:-304.7},0).to({scaleX:0.9975,scaleY:0.9975,rotation:129.5945,x:-50.9,y:68.7},64).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-183.4,-190.8,366.9,381.70000000000005);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EivZAAcIAAg3MFezAAAIAAA3g");
	mask.setTransform(0.025,0);

	// Layer_2
	this.instance = new lib.Symbol9("synched",0);
	this.instance.setTransform(474.6,-3.95);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-1075.75},119).wait(17).to({x:1340.8},0).to({x:486},138).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1122.6,-2.7,2245.3,5.5);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EivZAAcIAAg3MFezAAAIAAA3g");
	var mask_graphics_137 = new cjs.Graphics().p("EivZAAcIAAg3MFezAAAIAAA3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:0.025,y:0}).wait(137).to({graphics:mask_graphics_137,x:0.025,y:0}).wait(138));

	// Layer_2
	this.instance = new lib.Symbol8("synched",0);
	this.instance.setTransform(40.6,2.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:1190.05},61).to({x:-1087.3},1).to({x:40.6},75).to({x:1190.05},61).to({x:-1087.3},1).to({x:21.75},75).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1122.6,-2.7,2245.3,5.5);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EivZAAcIAAg3MFezAAAIAAA3g");
	mask.setTransform(0.025,0);

	// Layer_2
	this.instance = new lib.Symbol7("synched",0);
	this.instance.setTransform(1190.15,-6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-1069.85},135).wait(1).to({x:1190.15},0).to({x:-1069.85},135).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1122.6,-2.7,2245.3,5.5);


// stage content:
(lib.XBSL = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","#000000","rgba(0,0,0,0.067)"],[0,0.651,1],-7.9,138.4,-7.9,313.6).s().p("EALfA3bMiiYAAAMAAAhu2MEtzAAAMAAABu2g");
	this.shape.setTransform(965.825,354.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(275));

	// Symbol_1
	this.instance = new lib.Symbol3("synched",0);
	this.instance.setTransform(901.05,897.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(275));

	// Symbol_1
	this.instance_1 = new lib.Symbol4("synched",0);
	this.instance_1.setTransform(178.8,725.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(275));

	// Symbol_1
	this.instance_2 = new lib.Symbol5("synched",0);
	this.instance_2.setTransform(553.1,843.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(275));

	// Symbol_1
	this.instance_3 = new lib.Symbol6("synched",0);
	this.instance_3.setTransform(1044.65,821.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(275));

	// Symbol_1
	this.instance_4 = new lib.Symbol2("synched",0);
	this.instance_4.setTransform(901.05,825.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(275));

	// Symbol_1
	this.instance_5 = new lib.Symbol1("synched",0);
	this.instance_5.setTransform(901.05,666.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(275));

	// Layer_8
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#001111").s().p("EiQrAdsIAKAAIEiAAQAAgFACgDQF2nDF2nDIAAgFQoNgFoNAAIAAgKIAAg8IAKAAIRMAAQAFAAACgCQE1l5E6lzIAAgFQs5gFs5AAQAAAFgDADQgqAqgtAoIAAgKIAAiWQAZAAAPgMQFikgE8lJIAAgFQljgFljAAIAAgKIAAg8IAKAAIMWAAQAAgFADgCIIPoLIAAgFQqZgFqZAAIAAgKIAAiCQAFAAADgCIHOmEIgKAAInMAAIAAgKIAAgoIIcAAIAKAAQBVhVB0g1QAEgCAFAAQgoA8hXBAQgDABAAAFQJ9ASKXgIIAKAAIC0igIgEAIQgBACgFAAQAmAbhGAzQgiAagYAkQJ+ASKWgIIAKAAQBbhdBAg5IgFAKQARAhg/AxQgWAQgCAgQKCASKcgIIAKAAQA8heA3gzIAFAAQAFAAAFgFQAVAPg4BPIgjAuQKNASKlgNIAAgFQAthAAihMQAGgOAPAYQAIAnguBSQgCAEAAAFQKMASKmgIIAKAAQAZhpAZgtIAFAFQAFAFAKAAQAOhHAGAzIAAAKQgaBAgNBMIgBAKIUyAAIAKAAQAShQAOhdQAIAbABAbQAEBLAFAiQKLASKmgIIAKAAQgQhdAQg+IAIAIQAOAOgCgRQgEhQAMAfQACAEAAAFIAPC0IAFAAQKMASKmgIIAKAAQgfhnALgqIAAAFQAXgmATBaQAKAzASAlQKmAIKMgSIAKAAQgshfgBgjIAFAAQAagMAfBKIAhBOQKlAIKNgSIAKAAQgyg9gZhPIAFAAQBTA1ApBfQABACAFAAQKUAAKUgFIAAgFQg5hNgcg1IAFAAQAJgrA5BOQAoA2AsAzQKUAAKUgFIAAgFQg8hBg3hBIAFAAQB4AoAwBvQACAEAAAFQgzAjhjgDQpggTpGARQDBDoDDDmQACADAAAFQHtgHHTAWIAAAFQgoAzhvgGQmDgWlqARQDaEVDmEJQACADAAAFQDtgHDVAWIAAAFQgEAxh1gLQiYgPh/ARQDBDUChDzQAGALAAAOQgeAKg1hEQipjciyjUQsCAAsCAFIAAAFIGdJ9QACACAFAAQMRAKMRAPIAAAFQAGAwhqgEQrYgVq+ARQD4F+D1GCQACACAFAAQN/AAN/ACQAgAAgWgWQg1guADgrQAAgBAIgEQACgBAAgFQBIArAuBFQACADAAAFQC+gOCHAiIgFAAQgZAyhggOQhXgNg+ARQCgCrB7DLQAIAMgBAOQgYATgvg8IkhlxI7+ABIgegBQEgHiE8HIQABACAFAAQMlAKMlAPIAAAFIgoAAI7+AAI7+AAI7+AAI7+AAI7+AAI79AAI7+AAI7+AAI7+AAI7+AAQjhAAjgARIgYABQhZAAgSg6gEhhLAPeQgFAAgBADQkdHDkrG0QBGAjB4gCQN/gNN/AAQAAgFACgEQDUnEDOnLIgeAAQkPgCkMAAQpzAApmAMgAocPeQgkGsgrGmQAAAUAKAHQBHAwCBgCQONgNNcAAIgBgKQgdnWg8m4IgUAAI79AAIgBAKgEAy0APeQCFHHB9HRQBcgRB2ABQOOAGNcAAQAAgFgCgEQjQnNjcnCIgUAAI7+AAQAAAFACAFgAVRPeIBPOYQBdgRB1ACQOHANNtgSQAAgFgCgEQiBnBiBnEIgUAAI7+AAIABAKgEh+0APXQl0HKl9HBQNpASOBABQCHAABBgTQAFAAABgCQEjnDElm/QgFgFgFAAQt/gFt/AAQgFAAgCADgEgl9APeQAAAFgCAFQiDG6h/HAQBFATCNAAQOGgBNugSIABgKQAonGAxm+IgoAAQkPgCkMAAQpzAApmAMgEhDfAPeQgFAAgBACImoOCQBdASB1gBQOOgHNcAAQAFAAAAgBQB8nRCDnGIgeAAQkPgCkMAAQpzAApmAMgEBQgAPdQDWHCDMHNIDIABQOHAHNtgSQAAgFgCgDQkpm/kjnHIgUAAI7+AAQAAAFACAEgEgiiACgQhaFshtFaQgLApAfAAQOGAHNugSIABgKQAolsAdl4IgKAAI58AAIgBAKgEBKkACfQCpF8CzFzIAUAAQOHAINtgSQgFAAgCgCQjzl5j6lzIgKAAI5oAAQAAAFACAEgEAvNACgQBpF7ByFzIAUAAQOHAINtgSQgFAAgBgCQixlyinl6IgKAAI58AAQAAAFABAFgAUBCgQAYGGA3FoIAUAAQOHAINtgSQgFAAAAgBQhol8hvlxIgKAAI5yAAIABAKgAnLCgIgBAKIhFKUIgCAUQgFAqARABQN+ARN/AAIgBgKQgdl3goltIAAgFQlfgFlbAAQnlAAncAKgEg9vACfQiiFwiwFhQgHAbARAAQN/ADN/AAQAAgFACgEQBnl4Bpl3IgKAAI58AAQAAAFgCAEgEhY7ACfQjqFyj0FpIAAAKQN/AKN/AAQAFAAABgCQCpl5CvlzIAAgFQs+gFs+AAQAAAFgCAEgEh0HACeQk1F0k1FyIAAAFQN/AFN/AAQAAgFACgDQD0lzD0lzIAAgFQs+gFs+AAQAAAFgCADgEBFagImQCTE4CNE+IAKAAQNAAIMogSQgFAAgCgCQjHlBjWkyIgKAAI3mAAQAAAFACAEgEAsPgIlICpJ1IAKAAQNBAIMngSQAAgFgCgEQiSk4iYk0IgKAAI3mAAIABAKgAmPolQgZE2gjErIAAAFQMwAXNLgIIAAgKQgik7gkk6IgKAAI3vAAIAAAKgAS7olQAbFCAqEzIAKAAIZoAAQAAgFgBgEQhikyhRlEIgKAAI36AAIABAKgA/UotQhXFBhiEyIAAAFQM+AFM+AAIABgKQAflMASkpIgKAAI3mAAQgFAAAAACgEg4lgImQiOE9icEvIAAAFQM5AFM5AAQAFAAABgBQBck7BSlDIgKAAI3wAAQAAAFgCAEgEhRtgIlQgFAAgBACQjEE8jQEtIAAAFQM5AFM5AAQAAgFACgEQCSk3COk/IgKAAQjogCjlAAQoYAAoLAMgEhq6gInQkCE7kNEyIAAAFQM5AFM5AAQAAgFACgDQDMk7DMk8IgKAAI3wAAQAAAFgDADgEiEEgInQk8E5lBE0IAAAFQMvAFMvAAQAFAAACgCQEAk+ELk1IAAgFQr4gFr4AAQAAAFgDADgEBYfgSIQCqEMCxEHIAKAAQL2AILcgSQAAgFgCgDQjgkAjWkKIgKAAI14AAQAAAFADAEgEBBCgSIQB5EHB1EMIAKAAQMAAILmgSQgFAAgCgCQilkOiykCIgKAAI14AAQAAAFACAEgEApcgSHQBQEIBOEKIAKAAQMAAILmgSQgFAAgBgCQh6kOiEkCIgKAAI2CAAQAAAFACAFgASIyHQAPETAjD/IAKAAQL/AILngSQAAgFgCgEQhPj/hFkKIgKAAI2CAAIAAAKgEhLpgSIQiiEHiwD4IAAAFQLmAXMAgIQAFAAABgCID0oaIgKAAI2CAAQAAAFgCAEgA8wyHQhIEChND8IAAAFQL4AeL4gZIAAgKQAYkKAkj+IgKAAI2MAAQAAAFgBAFgAlTyHQgcDfgWDjIAAAoIAAAUQL3AUL4AAIAAgKQgYkKgakIIgKAAI2BAAIAAAKgEg0NgSIQh4EJiAEAIAAAFQL4AFL4AAQAAgFACgEQBTkABBkTIgKAAI2CAAQAAAFgCAEgEhi7gSJQjfEGjhEEIAAAFQLzAFLzAAQAFAAACgCQCmkOCxkCIAAgFQrBgFrBAAQAAAFgCADgEh6YgSJQkNEEkMEGIAAAFQLzAFLzAAQAAgFACgDQDckJDakLIgKAAI14AAQAAAFgDADgEBTKgaaQCMDrCeDYIAKAAQK+AIKmgSQgFAAgCgCQi5jii8jeIgKAAI0UAAQAAAFACAEgEA9IgaaQBtDcBjDnIAKAAQLJAIKvgSQgFAAgCgCQiQjiiVjeIgKAAI0eAAQAAAFACAEgEAnPgaZQA8DlBFDdIAKAAQLIAIKwgSQgFAAgBgCQhtjZhfjnIgKAAI0oAAIABAKgARN6ZQAbDjAgDfIAKAAQLDAIKrgSQgFAAgBgBIhynBIgKAAI0yAAIABAKgAkr6ZQgHCygXCiIAABGIABAPQKuAhLIgIIAAgKQgIjtggjVIgKAAI0nAAIAAAKgEiH+gacQkEDhkLDaIAAAFQLEANKqgSQAFAAACgCQDfjfDcjhIgKAAI0UAAQAAAFgDACgA6k6ZQgzDbhEDJIAAAPQLBAPLBAAIABgKQAUjgATjiIgKAAI0oAAIgBAKgEgwdgaaQhgDkhwDVIAAAFQLGAFLGAAIABgJQA3jmBAjdIgKAAI0oAAQAAAFgCAEgEhGPgahQiNDoiZDYIAAAFQLBAFLBAAQAAgFACgEQBqjZBcjqIgKAAI0UAAQgFAAgBACgEhcIgagQi0DmjBDZIAAAFQK8AFK8AAQAAgFADgDQCRjbCOjfIAAgFQqPgFqPAAQgFAAgCADgEhyGgabQjeDejhDcIAAAFQK3AFK3AAQAAgFACgDQDCjcC4joIgKAAI0eAAQAAAFgDADg");
	this.shape_1.setTransform(926,885.9929);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(275));

	// Delete_This_Layer
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("EB6CBUYI7+AAI7+AAI7+AAI7+AAI79AAI7+AAI7+AAI7+AAI7+AAI0UAAIAA7+IAA7+IAA7+IAA79IAA7+IAA7+IAAg8Ib+AAIb+AAIb+AAIb+AAIb+AAIb9AAIb+AAIb+AAIb+AAIb+AAIUUAAIAAb+IAAb+IAAb+IAAb9IAAb+IAAb+IAAA8I7+AAg");
	this.shape_2.setTransform(960,540);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(275));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(738.5,540,1285.2,543);
// library properties:
lib.properties = {
	id: 'A003F0EED673B244A7AF4AD9F4E79042',
	width: 1920,
	height: 1080,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A003F0EED673B244A7AF4AD9F4E79042'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;