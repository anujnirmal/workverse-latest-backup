// $(".program-mobile-slider").owlCarousel({
//     items: 1,
//     loop: false,
//     margin: 500,
//     nav: true,
//     autoplay: false,
//     autoplayTimeout: 9000,
//     autoplayHoverPause: true,
//     center: false,
//     smartSpeed: 1000,
//     freeDrag: false,
//     touchDrag  : false,
//     mouseDrag: false,
   
//     navText: [
//         "<i class='fa fa-angle-left'></i>",
//         "<i class='fa fa-angle-right'></i>"
//     ],
//     responsive: {
//         0: {
//             items: 1
//         },
//         600: {
//             items: 1
//         },
//         1024: {
//             items: 1
//         },
//         1025: {
//             items: 1
//         }
//     }
// });